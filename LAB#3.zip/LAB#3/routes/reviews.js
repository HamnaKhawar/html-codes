var express = require('express');
var router = express.Router();
var Review = require("../models/reviews");

router.get('/', async function(req, res, next) {
  try {
    let allReviews = await Review.find();
    res.render("reviews/list", { title: "List of All Reviews", reviews: allReviews });
  } catch (err) {
    console.error(err);
    next(err);
  }
});

router.get("/add", function(req, res, next) {
  res.render("reviews/add");
});

router.post("/add", async function(req, res, next) {
  try {
    let newReview = new Review(req.body);
    await newReview.save();
    res.redirect("/reviews");
  } catch (err) {
    console.error(err);
    next(err);
  }
});

router.get("/delete/:id", async function(req, res, next) {
  try {
    let deletedReview = await Review.findByIdAndDelete(req.params.id);
    res.redirect("/reviews");
  } catch (err) {
    console.error(err);
    next(err);
  }
});

router.get("/edit/:id", async function (req, res, next) {
  try {
    let review = await Review.findById(req.params.id);
    res.render("reviews/edit", { review });
  } catch (err) {
    console.error(err);
    next(err);
  }
});

router.post("/edit/:id", async function(req, res, next) {
  try {
    let reviewToEdit = await Review.findById(req.params.id);
    reviewToEdit.prod_name = req.body.prod_name;
    reviewToEdit.review = req.body.review;
    await reviewToEdit.save();
    res.redirect("/reviews");
  } catch (err) {
    console.error(err);
    next(err);
  }
});

module.exports = router;
