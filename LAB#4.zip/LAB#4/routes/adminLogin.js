const express = require('express');
const router = express.Router();
const User = require('../models/user');

// GET /admin/login
router.get('/', (req, res) => {
  res.render('adminLogin');
});

// POST /admin/login
router.post('/', async (req, res) => {
  try {
    const { username, password } = req.body;
    // Find the user in the database
    const user = await User.findOne({ username });
    if (!user) {
      throw new Error('User not found');
    }
    // Verify the password
    if (user.password !== password) {
      throw new Error('Incorrect password');
    }
    console.log('Login successful!');
    req.session.successMessage = 'Login successful!'; // Store success message in session
    res.redirect('/'); // Redirect to the home page
  } catch (err) {
    console.error(err);
    res.render('adminLogin', { errorMessage: 'Login failed. Please try again.' });
  }
});

module.exports = router;
