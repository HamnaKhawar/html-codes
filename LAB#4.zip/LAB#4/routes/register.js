const express = require('express');
const router = express.Router();
const User = require('../models/user');

// GET /register
router.get('/', (req, res) => {
  res.render('register');
});

// POST /register
router.post('/', async (req, res) => {
  try {
    const { username, password } = req.body;
    // Create a new user
    const user = new User({ username, password });
    // Save the user to the database
    await user.save();
    console.log('Registration successful!');
    res.render('register', { successMessage: 'Registration successful!' });
  } catch (err) {
    console.error(err);
    res.render('register', { errorMessage: 'Registration failed. Please try again.' });
  }
});

module.exports = router;
