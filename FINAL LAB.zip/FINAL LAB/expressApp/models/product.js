var mongoose = require("mongoose");

var productSchema = mongoose.Schema({
  name: String,
  arrival_time: String,
  departure_time: String,
  capacity: String
});
const Product = mongoose.model("Product", productSchema);
module.exports = Product;